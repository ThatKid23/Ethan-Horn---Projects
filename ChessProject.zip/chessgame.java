
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rylan
 */
public class chessgame {
    private player[] players = new player[2]; 
    private chessboard board = new chessboard(); 
    private player currentTurn;
    private ArrayList<move> movesPlayed = new ArrayList<move>(); 
  
    public void initialize(player p1, player p2) 
    { 
        players[0] = p1; 
        players[1] = p2; 
  
        board.setBoard(); 
  
        if (p1.isWhiteSide()) { 
            this.currentTurn = p1; 
        } 
        else { 
            this.currentTurn = p2; 
        } 
  
        movesPlayed.clear(); 
    } 
  
    public boolean playerMove(player player, int startX, int startY, int endX, int endY) 
    { 
        cell startBox = board.getBox(startX, startY); 
        cell endBox = board.getBox(startY, endY); 
        move move = new move(player, startBox, endBox); 
        return this.makeMove(move, player); 
    } 
  
    private boolean makeMove(move move, player player) 
    { 
        piece sourcePiece = move.getStart().getPiece(); 
        if (sourcePiece == null) { 
            return false; 
        } 
  
        // valid player 
        if (player != currentTurn) { 
            return false; 
        } 
  
        if (sourcePiece.isWhite() != player.isWhiteSide()) { 
            return false; 
        } 
  
        // valid move? 
        if (!sourcePiece.canMove(board, move.getStart(), move.getEnd())) { 
            return false; 
        } 
  
        // kill
        piece destPiece = move.getStart().getPiece(); 
        if (destPiece != null) { 
            destPiece.setKilled(true); 
            move.setPieceKilled(destPiece); 
        } 
  
        // store the move 
        movesPlayed.add(move); 
  
        // move piece from the stat box to end box 
        move.getEnd().setPiece(move.getStart().getPiece()); 
        move.getStart().setPiece(null);
  
        // set the current turn to the other player 
        if (this.currentTurn == players[0]) { 
            this.currentTurn = players[1]; 
        } 
        else { 
            this.currentTurn = players[0]; 
        } 
  
        return true; 
    }
}
