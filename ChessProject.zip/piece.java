/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rylan
 */
public abstract class piece {
    
    private boolean killed = false; 
    private boolean white = false; 
  
    public piece(boolean white) 
    { 
        this.setWhite(white); 
    } 
  
    public boolean isWhite() 
    { 
        return this.white; 
    } 
  
    public void setWhite(boolean white) 
    { 
        this.white = white; 
    } 
  
    public boolean isKilled() 
    { 
        return this.killed; 
    } 
  
    public void setKilled(boolean killed) 
    { 
        this.killed = killed; 
    } 
  
    public abstract boolean canMove(chessboard board, cell start, cell end); 
    
}
