/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rylan
 */
public class move {
    private player player; 
    private cell start; 
    private cell end; 
    private piece pieceMoved; 
    private piece pieceKilled;
  
    public move(player player, cell start, cell end) 
    { 
        this.player = player;
        this.start = start;
        this.end = end;
        this.pieceMoved = start.getPiece();
    }
    
    public cell getStart() 
    { 
        return this.start; 
    } 
  
    public void setStart(cell s) 
    { 
        this.start = s; 
    }
    
    public cell getEnd() 
    { 
        return this.end; 
    } 
  
    public void setEnd(cell e) 
    { 
        this.end = e; 
    }
    
    public void setPieceKilled(piece p){
        pieceKilled = p;
    }
}
