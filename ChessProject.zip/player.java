/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rylan
 */
public class player { 
    public boolean whiteSide;
  
    public boolean isWhiteSide() 
    { 
        return this.whiteSide; 
    }
    
    public player(boolean whiteSide) 
    { 
        this.whiteSide = whiteSide;
    } 
}